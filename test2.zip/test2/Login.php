<?php

  include("config.php");

   $error=''; // Variable To Store Error Message

	if (isset($_POST['submit'])) {
	if (empty($_POST['userName']) || empty($_POST['password'])) {
	$error = "Username or Password is invalid";
	}
	else
	{

        $uname = $_POST['userName'];
        $password = $_POST['password'];
		$pro_code1 = $_POST['pro_code'];$qty=1;
        $query = "select * from user where username='".$uname."'and password='".$password."' limit 1";

        $result = mysqli_query($conn, $query);

        $queryType = "select type,id from user where username='".$uname."'and password='".$password."' limit 1";
        $resultType = mysqli_query($conn, $queryType);
        $count = mysqli_num_rows($resultType);
        $rows = mysqli_fetch_array($resultType);

        $_SESSION['login_user']=$uname;
			$_SESSION['login_user_id']= $rows["id"]  ;

        if(($count >= 1) && ($rows["type"] == 'admin') ) {
            echo "Successful";
			session_start();
			$_SESSION['login_user_id']= $rows["id"]  ;
			$_SESSION['login_user']= $uname ;
			$_SESSION['code']=$pro_code1;
            header('Location: http://localhost/test2/Admin.php');
        } else if(($count >= 1) && ($rows["type"] == 'customer') ) {
			session_start();
            echo "Login Successful.";
			$_SESSION['code']= $pro_code1;
			$_SESSION['login_user']= $uname ;$_SESSION['login_user_id']= $rows["id"]  ;
			header("Location:http://localhost/test2/home.php?user=login");
				exit();
        }
        else {
            echo "Not Registered Yet";
        }
    }}
 include("header.php");
?>

 <div class="container container1">
<legend><center><h2 class="heading"><b>Login Form</b></h2></center></legend><br>
<div class="login-form">
<div class="main-div">
    <div class="panel">
   <h2>Login</h2>
   <p>Please enter your username and password</p>
   </div>
    <form id="Login" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">

        <div class="form-group">

			 <input type="hidden" name="pro_code" value="<?php echo $pro_code;?>">
            <input type="text" class="form-control" id="inputEmail"  name="userName" placeholder="Enter UserName">

        </div>

        <div class="form-group">

            <input type="password" class="form-control" name="password" id="inputPassword" placeholder="**********" >

        </div>
        <input  name="p_code"  class="form-control"  type="hidden" value="<?php echo $pro_code;?>">
        <input type="submit" name="submit" value="Login" class="btn btn-primary"><br><br>
<span><?php echo $error; ?></span>
    </form>
	<h2> For new user or guest user please Select one button to continue shopping<h2>

		<a href="registration.php?user=register" class="btn btn-primary" type = "submit" >Register for 1% discount</a>
			<a href="guest.php?user=guest" class="btn btn-primary" type = "submit" >Guest Purchase</a>
    </div>

</div></div></div>

</body>
</html>

<style>
.main-divider{
  width:300px;
  margin:auto;
}
</style>

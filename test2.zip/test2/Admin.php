<!DOCTYPE html>
<?php
session_start();
include("config.php");
$user_login = @$_SESSION['login_user_id'];
 $login_session= @$_SESSION['login_user'];
$ses_sql=mysql_query("select username from user ");
$row = mysql_fetch_assoc($ses_sql);
$login_session = $row['username'];
if(!empty($login_session)){

 $btn = @$_GET['queries'];

        if ($btn == "Admin") {
            header('Location: Admin.php');
        } else if ($btn == "Product List"){
            header('Location: products_upload.php');
        } else if ($btn == "Logout"){
            header('Location: logout.php');
        }elseif ($btn == "Insert") {
            header('Location: Insert.php');
        }

?>

<html>
<head>

    <title>Product</title>
    <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/bootstrap-theme.css" rel="stylesheet">
</head>
<body class="container">
 <form method="GET" >
    <br/>

<input class="btn btn-primary" type = "submit" name="queries" value="Admin">
<input type="submit" name="queries" value="Insert">
<input class="btn btn-primary" type = "submit" name="queries" value="Product List">
<input class="btn btn-danger" type = "submit" name="queries" value="Logout">
<br/>
<br/>
 </form>
 <div>
    <table class="table table-striped">

        <tr>
            <th>ID</th>
            <th>NAME</th>
            <th>USER NAME</th>
            <th>TYPE</th>
			<th>Action</th>
        </tr>

 </form>
</body>
</html>

<?php


        $query = "select * from user";
        $result = mysql_query($query);
        $count = mysql_num_rows($result);

        if($count > 0) {
            //echo "<table border='1'>";
            while($row = mysql_fetch_assoc($result)) {

                    echo "<tr><td>".$row["id"]. "</td><td>".$row["name"]."</td><td>".$row["username"]."</td><td>".$row["type"]."</td>  <td><a href='update_my.php?update_id=".$row["id"]."&table_name=users'>Update</a>/ <a href='delete.php?user_id=".$row["id"]."&delete=user'>Delete</a></td></tr>";
            }
          echo "</table>";
        }
        else {
            echo "O Results";
        }

        mysql_close($conn);



}

?>

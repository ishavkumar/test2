<?php

 include("config.php");
			$user = @$_GET['user'];
		 if(!isset($login_session) && isset($_POST['form_submit']) ) {

			$uname = $_POST['username'];
			$password = $_POST['user_password'];
			$name = $_POST['first_name'];
			$gender = $_POST['gender'];
			 $phone = $_POST['contact_no'];
			$address = $_POST['address'];
			 $type = $_POST['type'];
			  $email = $_POST['email'];
      $query = mysqli_query($conn, "INSERT INTO `user`(  `name`,`type`, `username`, `password`, `gender`, `phone`, `address`, `email`) VALUES ('".$name."','".$type."','".$uname."','".$password."','".$gender."','".$phone."','".$address."','".$email."')");

	 	 if( $query){
        $queryType =mysqli_query($conn, "select * from user where username='".$uname."'and password='".$password."' limit 1");
       $result = mysqli_fetch_array($queryType);
	     $count = count($queryType);


        if(($count == 1) && ($result["type"] == 'admin') ) {
		   session_start();
            echo "Successful";
			$_SESSION['login_user']=$uname;

			$_SESSION['login_user_id']= $result["id"]  ;
			header("Location:Admin.php", true, 301);
			exit();

        } else if(($count == 1) && ($result["type"] == 'customer' ||  $type != 'guest' )) {
		    session_start();
			$_SESSION['login_user']=$uname;

			$_SESSION['login_user_id']= $result["id"]  ;
            echo "You are successfully registered";
				header("Location:home.php?user=register", true, 301);
				exit();

        }
        else {
            echo "Not Registered Yet";
        }}
    }

 include("header.php");
?>

 <div class="container">
 <!---heading---->
    <form class="form-horizontal" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post"  id="contact_form">
<fieldset>

<!-- Form Name -->
<legend><center><h2 class="heading"><b>Registration Form</b></h2></center></legend><br>

<!-- Text input
     <header class="heading"> Registration-Form</header><hr></hr>
	<!---Form starting---->
	<div class="row">
	 <!--- For Type---->
         <div class="col-sm-12 formtetxt">
             <div class="row">

		         <div class="col-xs-12 inputGroupContainer">
					<div class="input-group">
					  <input  name="type"  class="form-control" type="hidden" value="customer">
					</div>

             </div>
		      </div>
		 </div>
	 <!--- For Name---->
         <div class="col-sm-12 formtetxt">
             <div class="row">
			     <div class="col-xs-4">
          	         <label class="control-label">Name :</label> </div>
		         <div class="col-xs-8 inputGroupContainer">
					<div class="input-group">
					  <input  name="first_name" placeholder="First Name" class="form-control" id="fname" type="text">
					</div>

             </div>
		      </div>
		 </div>

		  <!-----------For Phone number-------->
		<div class="col-sm-12 formtetxt">
		         <div class="row">
				     <div class="col-xs-4" >
		 	              <label class="control-label">Phone No :</label></div>
				  <div class="col-xs-8 inputGroupContainer" >
					    	<div class="input-group">
						  <input name="contact_no" placeholder="(639)" class="form-control" type="text">
						</div>
				 </div>
          </div>
		  </div>
		  <!-----For Email---->
          <div class="col-sm-12 formtetxt">
		         <div class="row">
				     <div class="col-xs-4">
		 	              <label class="control-label">Email :</label></div>
				  <div class="col-xs-8 inputGroupContainer">
			            <div class="input-group">
						  <input name="email" placeholder="Email" class="form-control"  type="email">
						</div>
				 </div>
          </div>
		  </div>
	 		  <!--------------For Gender ----------------->
         <div class="col-sm-12 formtetxt">
		     <div class ="row">
                 <div class="col-xs-4">
			       <label class="control-label">Gender:</label>
				 </div>

			     <div class="col-xs-4">
				     <input type="radio" name="gender" value="boy">Male</input>
				 </div>

				 <div class="col-xs-4">
				     <input type="radio"  name="gender" value="girl" >Female</input>
			     </div>

		  	 </div>

		 </div>
     <!-----For email---->
		 <div class="col-sm-12 formtetxt">
		     <div class="row">
			     <div class="col-xs-4">
		             <label class="control-label" >Username :</label></div>
			     <div class="col-xs-8 inputGroupContainer"	>
			           <div class="input-group">
							<input name="username" placeholder="Enter Username" class="form-control"  type="text">
					</div>
		         </div>
		     </div>
		 </div>
	 <!-----For Password and confirm password---->
          <div class="col-sm-12 formtetxt">
		         <div class="row">
				     <div class="col-xs-4">
		 	              <label class="control-label">Password :</label></div>
				  <div class="col-xs-8 inputGroupContainer">
			            <div class="input-group">
						  <input name="user_password" placeholder="*********" class="form-control"  type="password">
						</div>
				 </div>
          </div>
		  </div>

		  <div class="col-sm-12 formtetxt">
		         <div class="row">
				     <div class="col-xs-4">
		 	              <label class="control-label"> Confirm Password :</label></div>
				  <div class="col-xs-8 inputGroupContainer">
			             <div class="input-group">
							  <input name="confirm_password" placeholder="********" class="form-control"  type="password">
						</div>
				 </div>
          </div>
		  </div>
		  <!------- Address ----------------------->
		  <div class="col-sm-12 formtetxt">
		         <div class="row">
				     <div class="col-xs-4">
		 	              <label class="control-label"> Address :</label></div>
				  <div class="col-xs-8 inputGroupContainer">
			             <div class="input-group">
							    <textarea  name="address" placeholder="Enter your address" class="form-control rounded-0" id="exampleFormControlTextarea1" rows="3"></textarea>
						</div>
				 </div>
          </div>
		  </div>
		  		<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-4"><br>
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="submit" name="form_submit" value="SUBMIT" class="btn btn-warning" >&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
  </div>
</div>
	 </div>



</fieldset>
</form>
</div>

</body>
</html>

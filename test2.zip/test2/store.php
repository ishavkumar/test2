<?php 
include("header.php");
?>
<br><br><br>
 <div class="container">
 
 <div class="row">
 <div class="col-sx-1">
 </div>
<div class="col-md-10">
    <div class="row">
        <div class="col-sm-7">
		<ul>
            <li><b>Store located in Shopping mall/center :</b>   Yonge Eglinton Centre<br>
                <b> Store brand name :</b> Best Buy<br>
                <b> Address & Location :</b>2300 Yonge St, Toronto, ON M4P 1E4, Canada<br>
                <b>State : </b>Ontario<br> 
                <b> City :</b> Toronto<br>
			</li>
			<li><b>Store located in Shopping mall/center :</b> CF Fairview Mall<br>
			    <b>Store brand name :</b> Best Buy<br>
                <b>Address & Location : </b>1800 Sheppard Ave. East, Toronto, ON, M2J 5A7<br>
                 <b>State : </b>Ontario <br>
                <b>City : </b>Toronto <br>
			 </li>
             <li><b>Store located in Shopping mall/center :</b> Mappins<br>
                 <b>Store brand name : </b>Jewelry Store<br>
                 <b>Address & Location :</b> 3401 Dufferin St, Sp 163, Toronto, ON M6A 2T9, Canada<br>
                 <b>State : </b>Ontario<br> 
                 <b>City : </b>Toronto<br>
             </li>
             <li><b>Store located in Shopping mall/center : </b>Centerpoint Mall<br>
                 <b>Store brand name : </b>Best Buy<br>
                 <b>Address & Location : </b>6464 Yonge Street, Toronto, ON M2M 3X7, Canada<br>
                 <b>State :</b> Ontario<br> 
                 <b>City :</b> Toronto<br> 			 
             </li>
			 <li><b>Store located in Shopping mall/center :</b>CF Shops at Don Mills<br>
                 <b>Store brand name : </b>Best Buy<br>
                 <b>Address & Location : </b>1090 Don Mills Rd, Toronto, ON M3C 3R6, Canada<br>
                 <b>State :</b> Ontario<br> 
                 <b>City :</b> Toronto<br> 
			</li>	 
</ul>		  
        </div>
        <div class="col-sm-5">
           	<div id="map-detail" class="canadamap">
			<img src="image/mAP1.png" height="500px" width="600px">
        </div>
    </div>
	 <div class="col-md-1">
 </div>
</div>

</div>
</div>
</div>

</body>
</html>

<!Doctype html>
<html>
<head>
     <meta charset="UTF-8">
     <title>Shopping</title>
     	<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="style.css" rel="stylesheet">
		<link href="css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
		<script src="jquery/jquery.min.js"></script>
		<script src="jquery/bootstrap.min.js"></script>
		<script src="jquery/bootstrapvalidator.min.js"></script>


			<script>
		  $(document).ready(function() {
    $('#contact_form').bootstrapValidator({
        // To use feedback icons, ensure that you use Bootstrap v3.1.0 or later
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            first_name: {
                validators: {
                        stringLength: {
                        min: 2,
                    },
                        notEmpty: {
                        message: 'Please enter your First Name'
                    }
                }
            },
			 username: {
                validators: {
                     stringLength: {
                        min: 6,
                    },
                    notEmpty: {
                        message: 'Please enter your Username'
                    }
                }
            },
			 email: {
				validators: {
				  required: true,
				  email: true
				}
			  },
			 user_password: {
                validators: {
                     stringLength: {
                        min: 8,
                    },
                    notEmpty: {
                        message: 'Please enter your Password'
                    }
                }
            },
			confirm_password: {
                validators: {
                     stringLength: {
                        min: 8,
                    },
                    notEmpty: {
                        message: 'Please confirm your Password'
                    }
                }
            },

            contact_no: {
                validators: {
                  stringLength: {
                        min: 12,
                        max: 12,
                    notEmpty: {
                        message: 'Please enter your Contact No.'
                     }
                }
            },
			 department: {
                validators: {
                    notEmpty: {
                        message: 'Please select your Department/Office'
                    }
                }
            },
                }
            }
        })
        .on('success.form.bv', function(e) {
            $('#success_message').slideDown({ opacity: "show" }, "slow") // Do something ...
                $('#contact_form').data('bootstrapValidator').resetForm();

            // Prevent form submission
            e.preventDefault();

            // Get the form instance
            var $form = $(e.target);

            // Get the BootstrapValidator instance
            var bv = $form.data('bootstrapValidator');

            // Use Ajax to submit form data
            $.post($form.attr('action'), $form.serialize(), function(result) {
                console.log(result);
            }, 'json');
        });
});
		</script>

</head>

<?php
include("config.php");
 ?>
<?php

				 $login_user = @$_SESSION['login_user'];
				 if(!empty($login_user)){
				@$ses_sql=mysqli_query($conn, "select username,id,type from user where username='".$login_user."'");
				$row  = mysqli_fetch_array($ses_sql);
				@$login_session = $row['username']; $login_user_id  = $row['id'];$type  = $row['type'];?>
<body>
   <header>
		<nav class="navbar navbar-inverse navbar-fixed-top">
		  <div class="container-fluid">
			<div class="navbar-header">
			  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
			 <a class="navbar-brand" href="index.php">MyStore</a>
			</div>
			<div class="collapse navbar-collapse" id="myNavbar">
			  <ul class="nav navbar-nav">
				<li <?php if (basename($_SERVER['PHP_SELF']) == "home.php"){ ?>class="active" <?php } else{ }?>><a href="home.php">Home</a></li>
			  <li <?php if (basename($_SERVER['PHP_SELF']) == "store.php"){ ?>class="active" <?php } else{ }?>><a href="store.php">Store</a></li>
			  </ul>

			  <ul class="nav navbar-nav navbar-right">
				<?php if(isset($login_user) && $type=="admin"){  ?><li><a href="Admin.php">Welcome : <i><?php echo ucfirst($login_session); ?></i></a></li><?php }else{?><li>Welcome : <i><?php echo ucfirst($login_session); ?></i></li><?php }?>
				<?php if(isset($login_user)){?><li <?php if (basename($_SERVER['PHP_SELF']) == "logout.php"){ ?>class="active" <?php } else{ }?>><a href="logout.php"> Logout</a></li><?php }else{}?>

			  </ul>
			</div>
		  </div>
		</nav>

    </header><?php } ?>
    <!--Main Navigation-->

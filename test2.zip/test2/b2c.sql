-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2018 at 08:23 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `b2c`
--

-- --------------------------------------------------------

--
-- Table structure for table `cartdetails`
--

CREATE TABLE IF NOT EXISTS `cartdetails` (
`cartid` int(10) NOT NULL,
  `productid` int(11) NOT NULL,
  `pro_name` varchar(255) NOT NULL,
  `pimage` varchar(255) NOT NULL,
  `cartqty` int(11) NOT NULL,
  `price` varchar(255) NOT NULL,
  `userid` int(11) NOT NULL,
  `usertype` varchar(255) NOT NULL,
  `procode` varchar(255) NOT NULL,
  `users` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cartdetails`
--

INSERT INTO `cartdetails` (`cartid`, `productid`, `pro_name`, `pimage`, `cartqty`, `price`, `userid`, `usertype`, `procode`, `users`) VALUES
(4, 2, 'Women''s Black Top', 'img-1.jpg', 1, '11.9', 1, 'customer', '2423', '1'),
(7, 2, 'Women''s Black Top', 'img-1.jpg', 1, '14', 0, 'guest', '2423', 'guest'),
(8, 2, 'Women''s Black Top', 'img-1.jpg', 1, '11.9', 8, 'customer', '2423', '1');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
`orderid` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL,
  `total_price` int(11) NOT NULL,
  `p_code` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderid`, `product_id`, `product`, `qty`, `total_price`, `p_code`, `image`) VALUES
(2, 1, 'Men''s Blue Shirt', 1, 18, '4323', 'img-3.jpg'),
(9, 2, 'Women''s Black Top', 1, 14, '2423', 'img-1.jpg'),
(10, 3, 'Women''s White Top', 1, 13, '4354', 'img-7.jpg'),
(11, 2, 'Women''s Black Top', 1, 14, '2423', 'img-1.jpg'),
(12, 2, 'Women''s Black Top', 1, 14, '2423', 'img-1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
`id` int(10) NOT NULL,
  `prodct_name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `p_price` int(11) NOT NULL,
  `p_quantity` int(11) NOT NULL,
  `code` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `prodct_name`, `description`, `image`, `p_price`, `p_quantity`, `code`) VALUES
(1, 'Men''s Blue Shirt', 'Good PRODUCT', 'img-3.jpg', 18, 12, '4323'),
(2, 'Women''s Black Top', 'Good Product', 'img-1.jpg', 14, 12, '2423'),
(3, 'Women''s White Top', 'Good product', 'img-7.jpg', 13, 20, '4354'),
(4, 'Men''s white Shirt', 'Good Product', 'img-5.jpg', 23, 12, '2322'),
(5, 'Baby shirts', 'Good shirt for small babies', 'baby.jpg', 34, 22, '2343');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `type`, `username`, `password`, `gender`, `phone`, `address`, `email`) VALUES
(1, 'shab', 'customer', 'admin1', 'admin123', 'boy', '555555555555', 'zdsfs', 'shab12@gmail.com'),
(7, 'shab', 'guest', '', '', '', '', 'cssaa', 'shab@gmail.com'),
(8, 'ss', 'customer', 'admin12', 'admin123', 'girl', '555555555555', 'ssfdsf', 'test12@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cartdetails`
--
ALTER TABLE `cartdetails`
 ADD PRIMARY KEY (`cartid`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
 ADD PRIMARY KEY (`orderid`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cartdetails`
--
ALTER TABLE `cartdetails`
MODIFY `cartid` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
MODIFY `orderid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

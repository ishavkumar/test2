<?php

 include("config.php");
			$user = @$_GET['user'];

	if(isset($_POST['checkout']) ) {

			$guest_email = $_POST['guest_email'];
			 $guest_address = $_POST['guest_address'];
			$guest_name = $_POST['guest_name'];
			 $type = $_POST['type'];
			$userval = $_POST['users'];
			$query1 = "INSERT INTO user(type,name,email,address) VALUES ('".$type."','".$guest_name."','".$guest_email."','".$guest_address."')";
			 $addguest = mysqli_query($conn, $query1);

        if( $addguest) {
			session_start();
             $queryType =mysqli_query($conn, "select * from user where email='".$guest_email ."'and type='".$type."' limit 1");
       $result = mysqli_fetch_array($queryType);
	     $count = count($queryType);

			$_SESSION['login_user_id']=  $result['id'];
            header("Location:home.php?user=".$userval, true, 301);

			//unset($_SESSION["shopping_cart"]) ;
        }
        else {
            echo "Not Registered Yet";
        }
    }
 include("header.php");
?>
<div class="container">
<br><br><br>

<h1> Enter details for guest purchase</h1>
 <form class="form-horizontal" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" id="guest_form">
<input  name="users" value="guest" class="form-control"  type="hidden">
	<!-----For Email Address---->
          <div class="col-sm-12 formtetxt">
		         <div class="row">
				     <div class="col-xs-4">
		 	              <label class="control-label">Email :</label></div>
				  <div class="col-xs-8 inputGroupContainer">
			            <div class="input-group">
						  <input name="guest_email" class="form-control"  type="email" >
						</div>
				 </div>
          </div>
		  </div>

		  <!--- For Your Name---->
         <div class="col-sm-12 formtetxt">
             <div class="row">
			     <div class="col-xs-4">
          	         <label class="control-label"> Name :</label> </div>
		         <div class="col-xs-8 inputGroupContainer">
					<div class="input-group">
					  <input  name="guest_name" placeholder="Enter your name" class="form-control"  type="text">
					</div>

             </div>
		      </div>
		 </div>
		  <!-------Guest Address ----------------------->
		  <div class="col-sm-12 formtetxt">
		         <div class="row">
				     <div class="col-xs-4">
		 	              <label class="control-label"> Guest Address  :</label></div>
				  <div class="col-xs-8 inputGroupContainer">
			             <div class="input-group">
							    <textarea  name="guest_address" placeholder="Enter your address" class="form-control rounded-0" id="exampleFormControlTextarea1" rows="3"></textarea>
						</div>
				 </div>
          </div>
		  </div>  <!--- For Type---->
         <div class="col-sm-12 formtetxt">
             <div class="row">

		         <div class="col-xs-12 inputGroupContainer">
					<div class="input-group">
					  <input  name="type"  class="form-control"  type="hidden" value="guest">
					</div>

             </div>
		      </div>
		 </div>
		 <input type="submit" name="checkout" value="Submit" class="btn btn-info"></form>
